package io.mylyricx.hud;

import io.mylyricx.MyLyricXClient;
import io.mylyricx.audio.AudioPlayerService;
import io.mylyricx.config.MyLyricXConfig;
import io.mylyricx.lyrics.LrcParser;
import io.mylyricx.lyrics.LyricLine;
import io.mylyricx.playlist.TrackEntry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.DeltaTracker;

import java.util.List;

public final class LyricsHudOverlay {
    public static final int HUD_WIDTH = 240;
    public static final int HUD_HEIGHT = 64;

    private static final int BG_TOP = 0xB8180C2E;
    private static final int BG_BOTTOM = 0xC8100720;
    private static final int BORDER_PURPLE = 0xCC7B2CBF;
    private static final int ACCENT_CYAN = 0xFF00F5D4;
    private static final int TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int TEXT_SECONDARY = 0xFFB8A9D9;
    private static final int TEXT_MUTED = 0xFF7D6B9E;
    private static final int BAR_BG = 0x882B194D;

    private LyricsHudOverlay() { }

    public static void render(GuiGraphicsExtractor graphics, DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;

        MyLyricXConfig config = MyLyricXClient.getConfig();
        AudioPlayerService player = MyLyricXClient.getPlayerService();
        if (config == null || !config.hudEnabled || player == null) return;

        TrackEntry track = player.getCurrentTrack();
        if (track == null && !player.isPlaying() && !player.isPaused()) return;

        int screenW = graphics.guiWidth();
        int screenH = graphics.guiHeight();
        int x = Math.max(2, Math.min(config.hudX, Math.max(2, screenW - HUD_WIDTH - 2)));
        int y = Math.max(2, Math.min(config.hudY, Math.max(2, screenH - HUD_HEIGHT - 2)));
        Font font = client.font;

        graphics.fillGradient(x, y, x + HUD_WIDTH, y + HUD_HEIGHT, BG_TOP, BG_BOTTOM);
        graphics.fill(x, y, x + HUD_WIDTH, y + 1, BORDER_PURPLE);
        graphics.fill(x, y + HUD_HEIGHT - 1, x + HUD_WIDTH, y + HUD_HEIGHT, BORDER_PURPLE);
        graphics.fill(x, y, x + 1, y + HUD_HEIGHT, BORDER_PURPLE);
        graphics.fill(x + HUD_WIDTH - 1, y, x + HUD_WIDTH, y + HUD_HEIGHT, BORDER_PURPLE);
        graphics.fill(x + 1, y + 1, x + 3, y + HUD_HEIGHT - 1, ACCENT_CYAN);

        String stateBadge = player.isPlaying() ? "▶ " : (player.isPaused() ? "Ⅱ " : "■ ");
        String title = track != null ? track.title() : "No Track";
        String header = trimToWidth(font, stateBadge + title, HUD_WIDTH - 68);
        graphics.text(font, header, x + 8, y + 6, ACCENT_CYAN, true);

        long posMs = player.getPositionMs();
        long durMs = player.getDurationMs();
        String timeLabel = formatTime(posMs) + (durMs > 0 ? "/" + formatTime(durMs) : "");
        graphics.text(font, timeLabel, x + HUD_WIDTH - font.width(timeLabel) - 7, y + 6, TEXT_SECONDARY, true);

        List<LyricLine> lyrics = player.getCurrentLyrics();
        String currentLineText;
        String nextLineText = "";
        if (lyrics.isEmpty()) {
            currentLineText = (track != null && !track.hasLyrics())
                ? "No .lrc lyrics file found" : "Instrumental / Waiting for lyrics...";
        } else {
            int activeIdx = LrcParser.findActiveLineIndex(lyrics, posMs);
            if (activeIdx < 0) {
                currentLineText = "♪ ...";
                nextLineText = lyrics.get(0).text();
            } else {
                String active = lyrics.get(activeIdx).text();
                currentLineText = active.isEmpty() ? "♪" : active;
                if (activeIdx + 1 < lyrics.size()) nextLineText = lyrics.get(activeIdx + 1).text();
            }
        }

        graphics.text(font, trimToWidth(font, currentLineText, HUD_WIDTH - 18), x + 8, y + 25, TEXT_PRIMARY, true);
        if (config.showNextLyric && !nextLineText.isBlank()) {
            graphics.text(font, trimToWidth(font, "♪ " + nextLineText, HUD_WIDTH - 18), x + 8, y + 39, TEXT_MUTED, true);
        }

        int barX = x + 8;
        int barY = y + HUD_HEIGHT - 8;
        int barW = HUD_WIDTH - 16;
        graphics.fill(barX, barY, barX + barW, barY + 3, BAR_BG);
        if (durMs > 0) {
            float ratio = Math.max(0.0f, Math.min(1.0f, (float) posMs / (float) durMs));
            graphics.fill(barX, barY, barX + (int) (barW * ratio), barY + 3, ACCENT_CYAN);
        }
    }

    private static String trimToWidth(Font font, String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        String ellipsis = "…";
        int end = text.length();
        while (end > 0 && font.width(text.substring(0, end) + ellipsis) > maxWidth) end--;
        return end > 0 ? text.substring(0, end) + ellipsis : ellipsis;
    }

    public static String formatTime(long millis) {
        long totalSeconds = Math.max(0L, millis) / 1000L;
        return String.format("%d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }
}
