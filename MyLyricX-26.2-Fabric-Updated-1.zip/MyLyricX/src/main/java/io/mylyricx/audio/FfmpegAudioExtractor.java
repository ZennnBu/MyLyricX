package io.mylyricx.audio;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

public final class FfmpegAudioExtractor {
    private static final long TIMEOUT_SECONDS = 120L;

    private FfmpegAudioExtractor() {
    }

    public static boolean isFfmpegAvailable(String ffmpegBinary) {
        String cmd = (ffmpegBinary == null || ffmpegBinary.isBlank()) ? "ffmpeg" : ffmpegBinary;
        try {
            Process p = new ProcessBuilder(cmd, "-version")
                .redirectErrorStream(true)
                .start();
            boolean done = p.waitFor(5L, TimeUnit.SECONDS);
            if (!done) {
                p.destroyForcibly();
                return false;
            }
            return p.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static Path extractToTempWav(Path mp4File, String ffmpegBinary) throws IOException, InterruptedException {
        String cmd = (ffmpegBinary == null || ffmpegBinary.isBlank()) ? "ffmpeg" : ffmpegBinary;
        Path tempWav = Files.createTempFile("mylyricx_mp4_audio_", ".wav");
        tempWav.toFile().deleteOnExit();

        ProcessBuilder pb = new ProcessBuilder(
            cmd,
            "-y",
            "-v", "error",
            "-i", mp4File.toAbsolutePath().toString(),
            "-vn",
            "-sn",
            "-dn",
            "-acodec", "pcm_s16le",
            "-ar", "44100",
            "-ac", "2",
            tempWav.toAbsolutePath().toString()
        );
        pb.redirectErrorStream(true);

        Process process;
        try {
            process = pb.start();
        } catch (IOException startErr) {
            Files.deleteIfExists(tempWav);
            throw new IOException("FFmpeg executable not found ('" + cmd + "'). Install FFmpeg to play MP4 audio.", startErr);
        }

        byte[] output = process.getInputStream().readAllBytes();
        boolean finished = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        if (!finished) {
            process.destroyForcibly();
            Files.deleteIfExists(tempWav);
            throw new IOException("FFmpeg audio extraction timed out for: " + mp4File.getFileName());
        }
        if (process.exitValue() != 0 || !Files.isRegularFile(tempWav) || Files.size(tempWav) <= 44L) {
            Files.deleteIfExists(tempWav);
            String details = new String(output, StandardCharsets.UTF_8).trim();
            throw new IOException("FFmpeg could not extract audio from " + mp4File.getFileName()
                + (details.isEmpty() ? "" : ": " + details));
        }
        return tempWav;
    }
}
