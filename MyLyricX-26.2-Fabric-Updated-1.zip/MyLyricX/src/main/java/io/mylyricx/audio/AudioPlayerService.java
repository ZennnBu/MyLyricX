package io.mylyricx.audio;

import io.mylyricx.config.MyLyricXConfig;
import io.mylyricx.lyrics.LrcParser;
import io.mylyricx.lyrics.LyricLine;
import io.mylyricx.playlist.MusicFolderManager;
import io.mylyricx.playlist.TrackEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class AudioPlayerService {
    private static final Logger LOGGER = LoggerFactory.getLogger("MyLyricX");

    public enum RepeatMode {
        OFF, ALL, ONE
    }

    private final MusicFolderManager folderManager;
    private final MyLyricXConfig config;
    private final ExecutorService controlExecutor;

    private final AtomicReference<List<TrackEntry>> playlist = new AtomicReference<>(List.of());
    private final AtomicInteger currentIndex = new AtomicInteger(-1);
    private final AtomicReference<TrackEntry> currentTrack = new AtomicReference<>(null);
    private final AtomicReference<List<LyricLine>> currentLyrics = new AtomicReference<>(List.of());
    private final AtomicReference<String> statusMessage = new AtomicReference<>("Idle");

    private final AtomicBoolean playing = new AtomicBoolean(false);
    private final AtomicBoolean paused = new AtomicBoolean(false);
    private final AtomicBoolean shuffle = new AtomicBoolean(false);
    private final AtomicReference<RepeatMode> repeatMode = new AtomicReference<>(RepeatMode.OFF);
    private volatile float volume = 0.75f;

    private final AtomicLong positionMs = new AtomicLong(0L);
    private final AtomicLong durationMs = new AtomicLong(0L);
    private final AtomicLong seekTargetMs = new AtomicLong(-1L);
    private final AtomicInteger playbackGeneration = new AtomicInteger(0);

    private volatile SourceDataLine activeLine;
    private volatile Thread streamingThread;

    public AudioPlayerService(MusicFolderManager folderManager, MyLyricXConfig config) {
        this.folderManager = folderManager;
        this.config = config;
        this.volume = config.volume;
        this.shuffle.set(config.shuffle);
        try {
            this.repeatMode.set(RepeatMode.valueOf(config.repeatMode));
        } catch (IllegalArgumentException ignored) {
            this.repeatMode.set(RepeatMode.OFF);
        }

        this.controlExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MyLyricX-Control");
            t.setDaemon(true);
            return t;
        });
    }

    public void reloadPlaylist() {
        controlExecutor.execute(() -> {
            List<TrackEntry> scanned = folderManager.scanTracks();
            playlist.set(scanned);
            if (scanned.isEmpty()) {
                stopPlaybackInternal();
                currentIndex.set(-1);
                currentTrack.set(null);
                currentLyrics.set(List.of());
                positionMs.set(0L);
                durationMs.set(0L);
                statusMessage.set("No audio files in .minecraft/myMusics");
                return;
            }

            TrackEntry current = currentTrack.get();
            if (current != null) {
                for (int i = 0; i < scanned.size(); i++) {
                    if (scanned.get(i).audioFile().equals(current.audioFile())) {
                        currentIndex.set(i);
                        currentTrack.set(scanned.get(i));
                        currentLyrics.set(scanned.get(i).hasLyrics()
                            ? LrcParser.parseFile(scanned.get(i).lrcFile())
                            : List.of());
                        return;
                    }
                }
            }

            if (currentIndex.get() < 0 || currentIndex.get() >= scanned.size()) {
                currentIndex.set(0);
                TrackEntry first = scanned.get(0);
                currentTrack.set(first);
                currentLyrics.set(first.hasLyrics() ? LrcParser.parseFile(first.lrcFile()) : List.of());
                statusMessage.set("Ready: " + first.title());
            }
        });
    }

    public List<TrackEntry> getPlaylist() {
        return playlist.get();
    }

    public int getCurrentIndex() {
        return currentIndex.get();
    }

    public String getStatusMessage() {
        return statusMessage.get();
    }

    public void playIndex(int index) {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();
            if (tracks.isEmpty()) {
                tracks = folderManager.scanTracks();
                playlist.set(tracks);
            }
            if (index >= 0 && index < tracks.size()) {
                startTrackInternal(index);
            }
        });
    }

    public void playOrResume() {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();
            if (tracks.isEmpty()) {
                tracks = folderManager.scanTracks();
                playlist.set(tracks);
            }
            if (tracks.isEmpty()) {
                statusMessage.set("Add songs to .minecraft/myMusics");
                return;
            }
            if (paused.get() && activeLine != null) {
                paused.set(false);
                playing.set(true);
                TrackEntry track = currentTrack.get();
                statusMessage.set(track != null ? "Playing: " + track.title() : "Playing");
                return;
            }
            if (playing.get()) {
                return;
            }
            int idx = Math.max(0, Math.min(currentIndex.get(), tracks.size() - 1));
            startTrackInternal(idx);
        });
    }

    public void pause() {
        controlExecutor.execute(() -> {
            if (playing.get()) {
                playing.set(false);
                paused.set(true);
                SourceDataLine line = activeLine;
                if (line != null) {
                    line.stop();
                }
                statusMessage.set("Paused");
            }
        });
    }

    public void togglePlayPause() {
        if (playing.get()) {
            pause();
        } else {
            playOrResume();
        }
    }

    public void nextTrack() {
        controlExecutor.execute(() -> advanceTrackInternal(true));
    }

    public void previousTrack() {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();
            if (tracks.isEmpty()) {
                return;
            }
            if (positionMs.get() > 3_000L && (playing.get() || paused.get())) {
                startTrackInternal(Math.max(0, currentIndex.get()));
                return;
            }
            int prevIdx = currentIndex.get() - 1;
            if (prevIdx < 0) {
                prevIdx = tracks.size() - 1;
            }
            startTrackInternal(prevIdx);
        });
    }

    public void seekToMillis(long targetMs) {
        long clamped = Math.max(0L, targetMs);
        seekTargetMs.set(clamped);
    }

    public void setVolume(float newVolume) {
        this.volume = Math.max(0.0f, Math.min(1.0f, newVolume));
        config.volume = this.volume;
        SourceDataLine line = activeLine;
        if (line != null) {
            applyLineGain(line, this.volume);
        }
    }

    public float getVolume() {
        return volume;
    }

    public boolean isPlaying() {
        return playing.get();
    }

    public boolean isPaused() {
        return paused.get();
    }

    public boolean isShuffle() {
        return shuffle.get();
    }

    public void toggleShuffle() {
        boolean next = !shuffle.get();
        shuffle.set(next);
        config.shuffle = next;
        config.save();
    }

    public RepeatMode getRepeatMode() {
        return repeatMode.get();
    }

    public void cycleRepeatMode() {
        RepeatMode next = repeatMode.updateAndGet(mode -> switch (mode) {
            case OFF -> RepeatMode.ALL;
            case ALL -> RepeatMode.ONE;
            case ONE -> RepeatMode.OFF;
        });
        config.repeatMode = next.name();
        config.save();
    }

    public TrackEntry getCurrentTrack() {
        return currentTrack.get();
    }

    public List<LyricLine> getCurrentLyrics() {
        return currentLyrics.get();
    }

    public long getPositionMs() {
        return positionMs.get();
    }

    public long getDurationMs() {
        return durationMs.get();
    }

    private void advanceTrackInternal(boolean manualSkip) {
        List<TrackEntry> tracks = playlist.get();
        if (tracks.isEmpty()) {
            return;
        }
        RepeatMode mode = repeatMode.get();
        int cur = currentIndex.get();

        if (!manualSkip && mode == RepeatMode.ONE && cur >= 0 && cur < tracks.size()) {
            startTrackInternal(cur);
            return;
        }

        if (shuffle.get() && tracks.size() > 1) {
            List<Integer> candidates = new ArrayList<>();
            for (int i = 0; i < tracks.size(); i++) {
                if (i != cur) {
                    candidates.add(i);
                }
            }
            Collections.shuffle(candidates);
            startTrackInternal(candidates.get(0));
            return;
        }

        int nextIdx = cur + 1;
        if (nextIdx >= tracks.size()) {
            if (!manualSkip && mode == RepeatMode.OFF) {
                stopPlaybackInternal();
                positionMs.set(0L);
                statusMessage.set("Playlist finished");
                return;
            }
            nextIdx = 0;
        }
        startTrackInternal(nextIdx);
    }

    private void startTrackInternal(int index) {
        List<TrackEntry> tracks = playlist.get();
        if (index < 0 || index >= tracks.size()) {
            return;
        }

        stopPlaybackInternal();

        final int generation = playbackGeneration.incrementAndGet();
        final TrackEntry track = tracks.get(index);
        currentIndex.set(index);
        currentTrack.set(track);
        currentLyrics.set(track.hasLyrics() ? LrcParser.parseFile(track.lrcFile()) : List.of());
        positionMs.set(0L);
        durationMs.set(0L);
        seekTargetMs.set(-1L);
        paused.set(false);
        playing.set(true);
        statusMessage.set("Loading: " + track.title());

        Thread worker = new Thread(() -> streamTrackLoop(track, generation), "MyLyricX-Stream-" + generation);
        worker.setDaemon(true);
        streamingThread = worker;
        worker.start();
    }

    private void streamTrackLoop(TrackEntry track, int generation) {
        Path tempWavFile = null;
        SourceDataLine line = null;
        boolean completedNaturally = false;

        try {
            Path sourcePath = track.audioFile();
            if ("mp4".equals(track.extension())) {
                statusMessage.set("Extracting MP4 audio: " + track.title());
                tempWavFile = FfmpegAudioExtractor.extractToTempWav(sourcePath, config.ffmpegPath);
                if (generation != playbackGeneration.get()) {
                    return;
                }
                sourcePath = tempWavFile;
            }

            long estimatedDuration = estimateDurationMs(sourcePath, track.extension());
            durationMs.set(estimatedDuration);

            while (generation == playbackGeneration.get()) {
                long requestedSeekMs = seekTargetMs.getAndSet(-1L);
                long startOffsetMs = Math.max(0L, requestedSeekMs);

                try (InputStream fileIn = new BufferedInputStream(Files.newInputStream(sourcePath));
                     AudioInputStream rawStream = AudioSystem.getAudioInputStream(fileIn)) {

                    AudioFormat baseFormat = rawStream.getFormat();
                    float sampleRate = baseFormat.getSampleRate() > 0 ? baseFormat.getSampleRate() : 44100.0f;
                    int channels = baseFormat.getChannels() > 0 ? baseFormat.getChannels() : 2;

                    AudioFormat pcmFormat = new AudioFormat(
                        AudioFormat.Encoding.PCM_SIGNED,
                        sampleRate,
                        16,
                        channels,
                        channels * 2,
                        sampleRate,
                        false
                    );

                    try (AudioInputStream pcmStream = AudioSystem.getAudioInputStream(pcmFormat, rawStream)) {
                        if (line == null) {
                            DataLine.Info info = new DataLine.Info(SourceDataLine.class, pcmFormat);
                            line = (SourceDataLine) AudioSystem.getLine(info);
                            line.open(pcmFormat, 16384);
                            applyLineGain(line, volume);
                            activeLine = line;
                        }

                        long bytesPerSecond = (long) (sampleRate * channels * 2);
                        if (startOffsetMs > 0L && bytesPerSecond > 0L) {
                            long bytesToSkip = (startOffsetMs * bytesPerSecond) / 1000L;
                            bytesToSkip -= bytesToSkip % (channels * 2L);
                            skipFully(pcmStream, bytesToSkip);
                        }

                        long playedBytes = (startOffsetMs * bytesPerSecond) / 1000L;
                        positionMs.set(startOffsetMs);
                        statusMessage.set("Playing: " + track.title());
                        line.start();

                        byte[] buffer = new byte[4096];
                        boolean seekInterrupted = false;

                        while (generation == playbackGeneration.get()) {
                            if (seekTargetMs.get() >= 0L) {
                                line.flush();
                                seekInterrupted = true;
                                break;
                            }

                            if (paused.get()) {
                                Thread.sleep(25L);
                                continue;
                            }

                            if (!line.isRunning()) {
                                line.start();
                            }

                            int bytesRead = pcmStream.read(buffer, 0, buffer.length);
                            if (bytesRead < 0) {
                                line.drain();
                                completedNaturally = true;
                                break;
                            }
                            if (bytesRead > 0) {
                                applyLineGain(line, volume);
                                line.write(buffer, 0, bytesRead);
                                playedBytes += bytesRead;
                                if (bytesPerSecond > 0L) {
                                    long currentPos = (playedBytes * 1000L) / bytesPerSecond;
                                    positionMs.set(currentPos);
                                    if (currentPos > durationMs.get()) {
                                        durationMs.set(currentPos);
                                    }
                                }
                            }
                        }

                        if (!seekInterrupted) {
                            break;
                        }
                    }
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } catch (Exception ex) {
            LOGGER.error("Playback error for '{}': {}", track.title(), ex.getMessage());
            statusMessage.set("Error: " + track.title() + " (" + ex.getClass().getSimpleName() + ")");
        } finally {
            if (line != null) {
                try {
                    line.stop();
                    line.close();
                } catch (Exception ignored) {
                }
            }
            if (activeLine == line) {
                activeLine = null;
            }
            if (tempWavFile != null) {
                try {
                    Files.deleteIfExists(tempWavFile);
                } catch (Exception ignored) {
                }
            }
            if (generation == playbackGeneration.get()) {
                playing.set(false);
                paused.set(false);
                if (completedNaturally) {
                    controlExecutor.execute(() -> advanceTrackInternal(false));
                }
            }
        }
    }

    private static void skipFully(InputStream in, long bytesToSkip) throws Exception {
        long remaining = bytesToSkip;
        byte[] discard = new byte[4096];
        while (remaining > 0L) {
            long skipped = in.skip(remaining);
            if (skipped > 0L) {
                remaining -= skipped;
            } else {
                int read = in.read(discard, 0, (int) Math.min(discard.length, remaining));
                if (read < 0) {
                    break;
                }
                remaining -= read;
            }
        }
    }

    private static long estimateDurationMs(Path file, String ext) {
        try {
            var fileFormat = AudioSystem.getAudioFileFormat(file.toFile());
            Object durationProp = fileFormat.properties().get("duration");
            if (durationProp instanceof Long micros && micros > 0L) {
                return micros / 1_000L;
            }
            AudioFormat fmt = fileFormat.getFormat();
            if (fileFormat.getFrameLength() > 0 && fmt.getFrameRate() > 0) {
                return (long) ((fileFormat.getFrameLength() / fmt.getFrameRate()) * 1000.0);
            }
            long fileBytes = Files.size(file);
            if ("mp3".equals(ext) || "ogg".equals(ext)) {
                return (fileBytes * 8L) / 160L;
            }
        } catch (Exception ignored) {
        }
        return 0L;
    }

    private static void applyLineGain(SourceDataLine line, float vol) {
        try {
            if (line != null && line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
                float min = gain.getMinimum();
                float max = gain.getMaximum();
                if (vol <= 0.0001f) {
                    gain.setValue(min);
                } else {
                    float dB = (float) (20.0 * Math.log10(vol));
                    gain.setValue(Math.max(min, Math.min(max, dB)));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void stopPlaybackInternal() {
        playbackGeneration.incrementAndGet();
        playing.set(false);
        paused.set(false);
        SourceDataLine line = activeLine;
        activeLine = null;
        if (line != null) {
            try {
                line.stop();
                line.close();
            } catch (Exception ignored) {
            }
        }
        Thread worker = streamingThread;
        streamingThread = null;
        if (worker != null && worker != Thread.currentThread()) {
            worker.interrupt();
        }
    }

    public void shutdown() {
        stopPlaybackInternal();
        config.save();
        controlExecutor.shutdownNow();
    }
}
