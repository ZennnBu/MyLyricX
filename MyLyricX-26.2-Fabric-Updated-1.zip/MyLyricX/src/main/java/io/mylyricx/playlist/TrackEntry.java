package io.mylyricx.playlist;

import java.nio.file.Path;

public record TrackEntry(String title, Path audioFile, Path lrcFile, String extension) {
    public boolean hasLyrics() {
        return lrcFile != null;
    }
}
