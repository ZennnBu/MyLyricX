package io.mylyricx.lyrics;

public record LyricLine(long timestampMs, String text) implements Comparable<LyricLine> {
    @Override
    public int compareTo(LyricLine other) {
        return Long.compare(this.timestampMs, other.timestampMs);
    }
}
