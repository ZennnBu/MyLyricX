package io.mylyricx;

import com.mojang.blaze3d.platform.InputConstants;
import io.mylyricx.audio.AudioPlayerService;
import io.mylyricx.config.MyLyricXConfig;
import io.mylyricx.gui.MusicPlayerScreen;
import io.mylyricx.hud.LyricsHudOverlay;
import io.mylyricx.playlist.MusicFolderManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class MyLyricXClient implements ClientModInitializer {
    public static final String MOD_ID = "mylyricx";

    private static MyLyricXConfig config;
    private static AudioPlayerService playerService;

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(id("main"));

    private static KeyMapping openGuiKey;
    private static KeyMapping togglePlayKey;
    private static KeyMapping nextTrackKey;
    private static KeyMapping prevTrackKey;
    private static KeyMapping toggleLyricsKey;
    private static KeyMapping toggleShuffleKey;
    private static KeyMapping cycleRepeatKey;
    private static KeyMapping volumeUpKey;
    private static KeyMapping volumeDownKey;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitializeClient() {
        config = MyLyricXConfig.load(FabricLoader.getInstance().getConfigDir());
        openGuiKey = register("key.mylyricx.open_gui", GLFW.GLFW_KEY_M);
        togglePlayKey = register("key.mylyricx.toggle_play", GLFW.GLFW_KEY_P);
        nextTrackKey = register("key.mylyricx.next_track", GLFW.GLFW_KEY_RIGHT_BRACKET);
        prevTrackKey = register("key.mylyricx.prev_track", GLFW.GLFW_KEY_LEFT_BRACKET);
        toggleLyricsKey = register("key.mylyricx.toggle_lyrics", GLFW.GLFW_KEY_L);
        toggleShuffleKey = register("key.mylyricx.toggle_shuffle", GLFW.GLFW_KEY_UNKNOWN);
        cycleRepeatKey = register("key.mylyricx.cycle_repeat", GLFW.GLFW_KEY_UNKNOWN);
        volumeUpKey = register("key.mylyricx.volume_up", GLFW.GLFW_KEY_EQUAL);
        volumeDownKey = register("key.mylyricx.volume_down", GLFW.GLFW_KEY_MINUS);

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, id("lyrics_hud"), LyricsHudOverlay::render);

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            MusicFolderManager folderManager = new MusicFolderManager(FabricLoader.getInstance().getGameDir());
            playerService = new AudioPlayerService(folderManager, config);
            playerService.reloadPlaylist();
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            if (playerService != null) {
                playerService.shutdown();
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (playerService == null) return;

            while (openGuiKey.consumeClick()) {
                if (client.gui.screen() instanceof MusicPlayerScreen) {
                    client.gui.setScreen(null);
                } else {
                    client.gui.setScreen(new MusicPlayerScreen());
                }
            }
            while (togglePlayKey.consumeClick()) playerService.togglePlayPause();
            while (nextTrackKey.consumeClick()) playerService.nextTrack();
            while (prevTrackKey.consumeClick()) playerService.previousTrack();
            while (toggleLyricsKey.consumeClick()) {
                config.hudEnabled = !config.hudEnabled;
                config.save();
            }
            while (toggleShuffleKey.consumeClick()) playerService.toggleShuffle();
            while (cycleRepeatKey.consumeClick()) playerService.cycleRepeatMode();
            while (volumeUpKey.consumeClick()) {
                playerService.setVolume(playerService.getVolume() + 0.05f);
                config.save();
            }
            while (volumeDownKey.consumeClick()) {
                playerService.setVolume(playerService.getVolume() - 0.05f);
                config.save();
            }
        });
    }

    private static KeyMapping register(String translationKey, int keyCode) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(
            translationKey,
            InputConstants.Type.KEYSYM,
            keyCode,
            CATEGORY
        ));
    }

    public static MyLyricXConfig getConfig() {
        return config;
    }

    public static AudioPlayerService getPlayerService() {
        return playerService;
    }
}
