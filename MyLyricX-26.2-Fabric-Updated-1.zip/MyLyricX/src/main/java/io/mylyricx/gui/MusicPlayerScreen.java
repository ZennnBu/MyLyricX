package io.mylyricx.gui;

import io.mylyricx.MyLyricXClient;
import io.mylyricx.audio.AudioPlayerService;
import io.mylyricx.config.MyLyricXConfig;
import io.mylyricx.hud.LyricsHudOverlay;
import io.mylyricx.playlist.TrackEntry;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class MusicPlayerScreen extends Screen {
    private static final int PANEL_W = 360;
    private static final int PANEL_H = 258;
    private static final int BG_CARD_TOP = 0xE6160A2A;
    private static final int BG_CARD_BOT = 0xF00D061A;
    private static final int BORDER_PURPLE = 0xFF8A2BE2;
    private static final int CYAN = 0xFF00F5D4;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFB5A6D6;
    private final int page;

    public MusicPlayerScreen() { this(0); }

    private MusicPlayerScreen(int page) {
        super(Component.translatable("screen.mylyricx.title"));
        this.page = Math.max(0, page);
    }

    @Override
    protected void init() {
        AudioPlayerService player = MyLyricXClient.getPlayerService();
        MyLyricXConfig config = MyLyricXClient.getConfig();
        int left = (this.width - PANEL_W) / 2;
        int top = (this.height - PANEL_H) / 2;
        int ctrlY = top + 55;

        addButton("|<", left + 12, ctrlY, 34, () -> { if (player != null) player.previousTrack(); });
        addButton("Play/Pause", left + 50, ctrlY, 72, () -> { if (player != null) player.togglePlayPause(); });
        addButton(">|", left + 126, ctrlY, 34, () -> { if (player != null) player.nextTrack(); });
        addButton("Shuffle", left + 164, ctrlY, 58, () -> { if (player != null) player.toggleShuffle(); });
        addButton("Repeat", left + 226, ctrlY, 54, () -> { if (player != null) player.cycleRepeatMode(); });
        addButton("Scan", left + 284, ctrlY, 62, () -> { if (player != null) player.reloadPlaylist(); });

        int seekY = top + 82;
        addButton("-10s", left + 12, seekY, 48, () -> {
            if (player != null) player.seekToMillis(Math.max(0, player.getPositionMs() - 10_000));
        });
        addButton("+10s", left + 64, seekY, 48, () -> {
            if (player != null) player.seekToMillis(player.getPositionMs() + 10_000);
        });
        addButton("Vol -", left + 170, seekY, 48, () -> {
            if (player != null) { player.setVolume(player.getVolume() - 0.05f); if (config != null) config.save(); }
        });
        addButton("Vol +", left + 222, seekY, 48, () -> {
            if (player != null) { player.setVolume(player.getVolume() + 0.05f); if (config != null) config.save(); }
        });

        int listY = top + 112;
        List<TrackEntry> tracks = player != null ? player.getPlaylist() : List.of();
        int pageSize = 5;
        int start = page * pageSize;
        for (int row = 0; row < pageSize && start + row < tracks.size(); row++) {
            int index = start + row;
            TrackEntry track = tracks.get(index);
            String label = (index + 1) + ". " + track.title();
            if (track.hasLyrics()) label += "  [LRC]";
            addButton(label, left + 12, listY + row * 21, PANEL_W - 24, () -> {
                if (player != null) player.playIndex(index);
            });
        }
        if (start > 0) {
            addButton("< Page", left + 12, top + PANEL_H - 30, 68,
                () -> this.minecraft.gui.setScreen(new MusicPlayerScreen(page - 1)));
        }
        if (start + pageSize < tracks.size()) {
            addButton("Page >", left + 86, top + PANEL_H - 30, 68,
                () -> this.minecraft.gui.setScreen(new MusicPlayerScreen(page + 1)));
        }

        int hudY = top + PANEL_H - 30;
        addButton(config != null && config.hudEnabled ? "HUD: ON" : "HUD: OFF", left + 170, hudY, 66, () -> {
            if (config != null) { config.hudEnabled = !config.hudEnabled; config.save(); }
            this.minecraft.gui.setScreen(new MusicPlayerScreen(page));
        });
        addButton("Next lyric", left + 240, hudY, 78, () -> {
            if (config != null) { config.showNextLyric = !config.showNextLyric; config.save(); }
            this.minecraft.gui.setScreen(new MusicPlayerScreen(page));
        });
    }

    private void addButton(String label, int x, int y, int width, Runnable action) {
        this.addRenderableWidget(Button.builder(Component.literal(label), button -> action.run())
            .bounds(x, y, width, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        AudioPlayerService player = MyLyricXClient.getPlayerService();
        int left = (this.width - PANEL_W) / 2;
        int top = (this.height - PANEL_H) / 2;

        graphics.fillGradient(left, top, left + PANEL_W, top + PANEL_H, BG_CARD_TOP, BG_CARD_BOT);
        graphics.outline(left, top, PANEL_W, PANEL_H, BORDER_PURPLE);
        graphics.text(this.font, "MyLyricX // Music & Live Lyrics", left + 14, top + 10, CYAN, true);
        String status = player != null ? player.getStatusMessage() : "Audio player starting...";
        graphics.text(this.font, trim(status, PANEL_W - 28), left + 14, top + 26, TEXT_WHITE, true);

        int progX = left + 14;
        int progY = top + 43;
        int progW = PANEL_W - 28;
        long pos = player != null ? player.getPositionMs() : 0L;
        long dur = player != null ? player.getDurationMs() : 0L;
        float ratio = dur > 0 ? Math.max(0.0f, Math.min(1.0f, (float) pos / (float) dur)) : 0.0f;
        graphics.fill(progX, progY, progX + progW, progY + 5, 0xAA2A184A);
        graphics.fill(progX, progY, progX + (int) (progW * ratio), progY + 5, CYAN);

        String time = LyricsHudOverlay.formatTime(pos) + "/" + LyricsHudOverlay.formatTime(dur);
        String volume = "Volume: " + (player == null ? "0" : Math.round(player.getVolume() * 100) + "%");
        graphics.text(this.font, time, left + 14, top + 93, TEXT_DIM, true);
        graphics.text(this.font, volume, left + 120, top + 93, TEXT_DIM, true);
        graphics.text(this.font, "Playlist  •  Page " + (page + 1), left + 14, top + 104, CYAN, true);
    }

    private String trim(String text, int maxWidth) {
        if (this.font.width(text) <= maxWidth) return text;
        int end = text.length();
        while (end > 0 && this.font.width(text.substring(0, end) + "…") > maxWidth) end--;
        return end > 0 ? text.substring(0, end) + "…" : "…";
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
