package io.mylyricx.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class MyLyricXConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("MyLyricX");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean hudEnabled = true;
    public boolean showNextLyric = true;
    public int hudX = 12;
    public int hudY = 12;
    public float volume = 0.75f;
    public boolean shuffle = false;
    public String repeatMode = "OFF";
    public String ffmpegPath = "ffmpeg";

    private transient Path configFile;

    public static MyLyricXConfig load(Path configDir) {
        Path file = configDir.resolve("mylyricx.json");
        MyLyricXConfig cfg = new MyLyricXConfig();
        cfg.configFile = file;

        if (Files.isRegularFile(file)) {
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                MyLyricXConfig loaded = GSON.fromJson(reader, MyLyricXConfig.class);
                if (loaded != null) {
                    loaded.configFile = file;
                    loaded.clampValues();
                    return loaded;
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to read MyLyricX config, using defaults: {}", e.getMessage());
            }
        }
        cfg.save();
        return cfg;
    }

    public void clampValues() {
        this.hudX = Math.max(0, this.hudX);
        this.hudY = Math.max(0, this.hudY);
        this.volume = Math.max(0.0f, Math.min(1.0f, this.volume));
        if (this.ffmpegPath == null || this.ffmpegPath.isBlank()) {
            this.ffmpegPath = "ffmpeg";
        }
        if (this.repeatMode == null) {
            this.repeatMode = "OFF";
        }
    }

    public void save() {
        if (configFile == null) {
            return;
        }
        clampValues();
        try {
            Files.createDirectories(configFile.getParent());
            try (Writer writer = Files.newBufferedWriter(configFile, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            LOGGER.warn("Failed to save MyLyricX config: {}", e.getMessage());
        }
    }
}
