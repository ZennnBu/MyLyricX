# MyLyricX 1.2.2 - Porting and verification notes

## Changes applied

- Migrated the Gradle plugin to Fabric's non-remapping `net.fabricmc.fabric-loom` plugin for Minecraft 26.2.
- Removed Yarn mappings and all `modImplementation` declarations.
- Aligned Minecraft, Fabric Loader, Fabric API, Loom, Java and Gradle versions with Fabric's official 26.2 example project.
- Updated client code from the old Yarn 1.21.x names to the Mojang-name 26.2 client API: `Minecraft`, `KeyMapping`, `Identifier`, `GuiGraphicsExtractor`, `DeltaTracker`, `HudElementRegistry`, `Button`, `Component`, and `extractRenderState`.
- Replaced the deprecated legacy HUD callback with Fabric's HUD element registry.
- Kept the Android-friendly GitHub Actions workflow that installs Gradle directly; no wrapper JAR is required.
- Added merging for Java Sound SPI service descriptors so the MP3 and OGG decoder providers can both be discovered from the bundled mod JAR.

## Version sources

The selected Minecraft 26.2 values follow the official Fabric example-mod `26.2` branch: Loom `1.19-SNAPSHOT`, Loader `0.20.1`, Fabric API `0.161.0+26.2`, and Gradle `9.8.2`.

## Not verified in this environment

This archive has not been compiled with the Minecraft 26.2 dependencies or launched in the game. The available environment only has Java 21 and no Gradle installation; the project requires Java 25 and Gradle 9.8.2. Run the included GitHub Actions workflow and share its result if it fails. Audio hardware playback, MP3/OGG decoding, and MP4 extraction with FFmpeg also require in-game testing.
