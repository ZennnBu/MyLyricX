# MyLyricX 1.2.2

Client-side music player and synchronized `.lrc` lyrics HUD for **Minecraft 26.2 + Fabric**.

## Build on GitHub (Android-friendly)

This project intentionally does not require a checked-in Gradle Wrapper. GitHub Actions installs Java 25 and Gradle 9.8.2, then runs `gradle clean build`.

1. Upload the contents of this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build MyLyricX** and run the workflow (or push a commit).
4. When the run completes, open its summary and download the `MyLyricX-1.2.2-Minecraft-26.2` artifact.
5. Extract the artifact ZIP and put the mod `.jar` in the Minecraft `mods` folder alongside Fabric API.

## Music folders

On first launch, the mod creates:

```text
.minecraft/myMusics/
.minecraft/myMusics/Lyrics/
```

Place supported audio files in `myMusics` and same-basename `.lrc` files in `myMusics/Lyrics`.

Supported extensions are MP3, OGG, WAV and MP4 (audio stream only). MP4 playback requires FFmpeg to be installed and available on PATH, or configured with `ffmpegPath` in `config/mylyricx.json`.

## Default controls

- `M`: open/close music player
- `P`: play/pause
- `[` / `]`: previous/next track
- `L`: toggle lyrics HUD
- `=` / `-`: volume up/down

Shuffle and repeat can be controlled in the player screen.

## Important testing note

The Gradle configuration follows Fabric's official Minecraft 26.2 example project conventions: non-remapping Loom, no Yarn mappings, Java 25, Fabric Loader and Fabric API dependencies. The project has not yet been compiled or launched in a Minecraft 26.2 runtime in this environment. A successful GitHub Actions run is still required before treating the JAR as verified.
