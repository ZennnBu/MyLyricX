
package io.mylyricx.audio;

import io.mylyricx.config.MyLyricXConfig;
import io.mylyricx.lyrics.LrcParser;
import io.mylyricx.lyrics.LyricLine;
import io.mylyricx.playlist.MusicFolderManager;
import io.mylyricx.playlist.TrackEntry;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class AudioPlayerService {
    private static final Logger LOGGER =
            LoggerFactory.getLogger("MyLyricX");

    public enum RepeatMode {
        OFF, ALL, ONE
    }

    private final MusicFolderManager folderManager;
    private final MyLyricXConfig config;
    private final ExecutorService controlExecutor;

    private final AtomicReference<List<TrackEntry>> playlist =
            new AtomicReference<>(List.of());

    private final AtomicInteger currentIndex =
            new AtomicInteger(-1);

    private final AtomicReference<TrackEntry> currentTrack =
            new AtomicReference<>(null);

    private final AtomicReference<List<LyricLine>> currentLyrics =
            new AtomicReference<>(List.of());

    private final AtomicReference<String> statusMessage =
            new AtomicReference<>("Idle");

    private final AtomicBoolean playing =
            new AtomicBoolean(false);

    private final AtomicBoolean paused =
            new AtomicBoolean(false);

    private final AtomicBoolean shuffle =
            new AtomicBoolean(false);

    private final AtomicReference<RepeatMode> repeatMode =
            new AtomicReference<>(RepeatMode.OFF);

    private volatile float volume = 0.75f;

    private final AtomicLong positionMs = new AtomicLong(0L);
    private final AtomicLong durationMs = new AtomicLong(0L);
    private final AtomicLong seekTargetMs = new AtomicLong(-1L);

    private final AtomicInteger playbackGeneration =
            new AtomicInteger(0);

    private volatile AndroidAudioSink activeSink;
    private volatile Thread streamingThread;

    public AudioPlayerService(
            MusicFolderManager folderManager,
            MyLyricXConfig config
    ) {
        this.folderManager = folderManager;
        this.config = config;

        volume = clamp01(config.volume);
        shuffle.set(config.shuffle);

        try {
            repeatMode.set(
                    RepeatMode.valueOf(config.repeatMode)
            );
        } catch (Exception ignored) {
            repeatMode.set(RepeatMode.OFF);
        }

        controlExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(
                    r,
                    "MyLyricX-Control"
            );
            thread.setDaemon(true);
            return thread;
        });
    }

    public void reloadPlaylist() {
        controlExecutor.execute(() -> {
            List<TrackEntry> scanned =
                    folderManager.scanTracks();

            playlist.set(scanned);

            if (scanned.isEmpty()) {
                stopPlaybackInternal();

                currentIndex.set(-1);
                currentTrack.set(null);
                currentLyrics.set(List.of());

                positionMs.set(0L);
                durationMs.set(0L);

                statusMessage.set(
                        "No audio files in .minecraft/myMusics"
                );
                return;
            }

            TrackEntry current = currentTrack.get();

            if (current != null) {
                for (int i = 0; i < scanned.size(); i++) {
                    if (scanned.get(i).audioFile()
                            .equals(current.audioFile())) {

                        currentIndex.set(i);
                        currentTrack.set(scanned.get(i));

                        currentLyrics.set(
                                scanned.get(i).hasLyrics()
                                        ? LrcParser.parseFile(
                                                scanned.get(i).lrcFile()
                                        )
                                        : List.of()
                        );

                        return;
                    }
                }
            }

            if (currentIndex.get() < 0
                    || currentIndex.get() >= scanned.size()) {

                currentIndex.set(0);

                TrackEntry first = scanned.get(0);
                currentTrack.set(first);

                currentLyrics.set(
                        first.hasLyrics()
                                ? LrcParser.parseFile(first.lrcFile())
                                : List.of()
                );

                statusMessage.set("Ready: " + first.title());
            }
        });
    }

    public List<TrackEntry> getPlaylist() {
        return playlist.get();
    }

    public int getCurrentIndex() {
        return currentIndex.get();
    }

    public String getStatusMessage() {
        return statusMessage.get();
    }

    public void playIndex(int index) {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();

            if (tracks.isEmpty()) {
                tracks = folderManager.scanTracks();
                playlist.set(tracks);
            }

            if (index >= 0 && index < tracks.size()) {
                startTrackInternal(index);
            }
        });
    }

    public void playOrResume() {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();

            if (tracks.isEmpty()) {
                tracks = folderManager.scanTracks();
                playlist.set(tracks);
            }

            if (tracks.isEmpty()) {
                statusMessage.set(
                        "Add songs to .minecraft/myMusics"
                );
                return;
            }

            if (paused.get() && activeSink != null) {
                paused.set(false);
                playing.set(true);

                activeSink.play();

                TrackEntry track = currentTrack.get();

                statusMessage.set(
                        track != null
                                ? "Playing: " + track.title()
                                : "Playing"
                );
                return;
            }

            if (playing.get()) {
                return;
            }

            int index = Math.max(
                    0,
                    Math.min(
                            currentIndex.get(),
                            tracks.size() - 1
                    )
            );

            startTrackInternal(index);
        });
    }

    public void pause() {
        controlExecutor.execute(() -> {
            if (playing.get()) {
                playing.set(false);
                paused.set(true);

                AndroidAudioSink sink = activeSink;

                if (sink != null) {
                    sink.pause();
                }

                statusMessage.set("Paused");
            }
        });
    }

    public void togglePlayPause() {
        if (playing.get()) {
            pause();
        } else {
            playOrResume();
        }
    }

    public void nextTrack() {
        controlExecutor.execute(
                () -> advanceTrackInternal(true)
        );
    }

    public void previousTrack() {
        controlExecutor.execute(() -> {
            List<TrackEntry> tracks = playlist.get();

            if (tracks.isEmpty()) {
                return;
            }

            if (positionMs.get() > 3000L
                    && (playing.get() || paused.get())) {

                startTrackInternal(
                        Math.max(0, currentIndex.get())
                );
                return;
            }

            int previous = currentIndex.get() - 1;

            if (previous < 0) {
                previous = tracks.size() - 1;
            }

            startTrackInternal(previous);
        });
    }

    public void seekToMillis(long targetMs) {
        long target = Math.max(0L, targetMs);
        long duration = durationMs.get();

        if (duration > 0L) {
            target = Math.min(target, duration);
        }

        seekTargetMs.set(target);
    }

    public void setVolume(float newVolume) {
        volume = clamp01(newVolume);
        config.volume = volume;

        AndroidAudioSink sink = activeSink;

        if (sink != null) {
            sink.setVolume(volume);
        }
    }

    public float getVolume() {
        return volume;
    }

    public boolean isPlaying() {
        return playing.get();
    }

    public boolean isPaused() {
        return paused.get();
    }

    public boolean isShuffle() {
        return shuffle.get();
    }

    public void toggleShuffle() {
        boolean next = !shuffle.get();

        shuffle.set(next);
        config.shuffle = next;
        config.save();
    }

    public RepeatMode getRepeatMode() {
        return repeatMode.get();
    }

    public void cycleRepeatMode() {
        RepeatMode next = repeatMode.updateAndGet(mode -> switch (mode) {
            case OFF -> RepeatMode.ALL;
            case ALL -> RepeatMode.ONE;
            case ONE -> RepeatMode.OFF;
        });

        config.repeatMode = next.name();
        config.save();
    }

    public TrackEntry getCurrentTrack() {
        return currentTrack.get();
    }

    public List<LyricLine> getCurrentLyrics() {
        return currentLyrics.get();
    }

    public long getPositionMs() {
        return positionMs.get();
    }

    public long getDurationMs() {
        return durationMs.get();
    }

    private void advanceTrackInternal(boolean manual) {
        List<TrackEntry> tracks = playlist.get();

        if (tracks.isEmpty()) {
            return;
        }

        int next;

        if (repeatMode.get() == RepeatMode.ONE && !manual) {
            next = currentIndex.get();
        } else if (shuffle.get() && tracks.size() > 1) {
            next = currentIndex.get();

            while (next == currentIndex.get()) {
                next = (int) (Math.random() * tracks.size());
            }
        } else {
            next = currentIndex.get() + 1;

            if (next >= tracks.size()) {
                if (repeatMode.get() == RepeatMode.ALL || manual) {
                    next = 0;
                } else {
                    stopPlaybackInternal();
                    statusMessage.set("Playlist finished");
                    return;
                }
            }
        }

        startTrackInternal(next);
    }

    private void startTrackInternal(int index) {
        List<TrackEntry> tracks = playlist.get();

        if (index < 0 || index >= tracks.size()) {
            return;
        }

        stopPlaybackInternal();

        int generation = playbackGeneration.incrementAndGet();

        TrackEntry track = tracks.get(index);

        currentIndex.set(index);
        currentTrack.set(track);

        currentLyrics.set(
                track.hasLyrics()
                        ? LrcParser.parseFile(track.lrcFile())
                        : List.of()
        );

        positionMs.set(0L);
        durationMs.set(0L);
        seekTargetMs.set(-1L);

        playing.set(true);
        paused.set(false);

        statusMessage.set("Loading: " + track.title());

        Thread worker = new Thread(
                () -> streamTrackLoop(track, generation),
                "MyLyricX-Audio"
        );

        worker.setDaemon(true);
        streamingThread = worker;
        worker.start();
    }

    private void streamTrackLoop(
            TrackEntry track,
            int generation
    ) {
        AndroidAudioSink sink = null;

        try {
            DecodedPcmStream decoded = decodeAudio(track);

            if (generation != playbackGeneration.get()) {
                decoded.close();
                return;
            }

            long duration = decoded.durationMs();
            durationMs.set(duration);

            sink = new AndroidAudioSink(
                    decoded.sampleRate(),
                    decoded.channels(),
                    volume
            );

            activeSink = sink;
            sink.play();

            statusMessage.set("Playing: " + track.title());

            byte[] buffer = new byte[8192];
            long playedBytes = 0L;

            long totalBytes = decoded.totalPcmBytes();

            while (generation == playbackGeneration.get()) {

                if (paused.get()) {
                    Thread.sleep(40L);
                    continue;
                }

                long requestedSeek = seekTargetMs.getAndSet(-1L);

                if (requestedSeek >= 0L) {
                    decoded.close();

                    decoded = decodeAudio(track);

                    long bytesToSkip =
                            requestedSeek
                                    * decoded.sampleRate()
                                    * decoded.channels()
                                    * 2L / 1000L;

                    skipFully(decoded.stream(), bytesToSkip);

                    playedBytes = bytesToSkip;

                    positionMs.set(requestedSeek);

                    if (sink != null) {
                        sink.flush();
                    }

                    totalBytes = decoded.totalPcmBytes();
                    durationMs.set(decoded.durationMs());

                    continue;
                }

                int count = decoded.stream().read(
                        buffer,
                        0,
                        buffer.length
                );

                if (count < 0) {
                    break;
                }

                if (count == 0) {
                    continue;
                }

                sink.write(buffer, count);

                playedBytes += count;

                long bytesPerSecond =
                        (long) decoded.sampleRate()
                                * decoded.channels()
                                * 2L;

                if (bytesPerSecond > 0L) {
                    positionMs.set(
                            playedBytes * 1000L / bytesPerSecond
                    );
                }
            }

            decoded.close();

            if (generation == playbackGeneration.get()) {
                playing.set(false);
                paused.set(false);

                if (repeatMode.get() == RepeatMode.ONE) {
                    startTrackInternal(currentIndex.get());
                } else {
                    advanceTrackInternal(false);
                }
            }

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();

        } catch (Exception e) {
            LOGGER.error(
                    "Audio playback failed for {}: {}",
                    track.title(),
                    e.getMessage(),
                    e
            );

            if (generation == playbackGeneration.get()) {
                playing.set(false);
                paused.set(false);

                statusMessage.set(
                        "Audio error: " + e.getMessage()
                );
            }

        } finally {
            if (sink != null) {
                sink.release();
            }

            if (activeSink == sink) {
                activeSink = null;
            }
        }
    }

    private DecodedPcmStream decodeAudio(
            TrackEntry track
    ) throws Exception {

        String extension = track.extension()
                .toLowerCase(java.util.Locale.ROOT);

        return switch (extension) {
            case "mp3" -> decodeMp3WithJLayer(track.audioFile());
            case "wav" -> decodeWav(track.audioFile());
            default -> throw new IOException(
                    "Unsupported audio format: " + extension
            );
        };
    }

    private DecodedPcmStream decodeWav(
            Path file
    ) throws IOException {

        RandomAccessFile raf = new RandomAccessFile(
                file.toFile(),
                "r"
        );

        try {
            if (raf.length() < 12L) {
                throw new IOException("Invalid WAV file");
            }

            byte[] header = new byte[12];
            raf.readFully(header);

            if (!ascii(header, 0, 4).equals("RIFF")
                    || !ascii(header, 8, 4).equals("WAVE")) {
                throw new IOException("Not a valid WAV file");
            }

            int channels = 0;
            int sampleRate = 0;
            int bitsPerSample = 0;
            int audioFormat = 0;

            long dataOffset = -1L;
            long dataSize = -1L;

            while (raf.getFilePointer() + 8L <= raf.length()) {
                byte[] chunkHeader = new byte[8];
                raf.readFully(chunkHeader);

                String chunkName = ascii(chunkHeader, 0, 4);
                long chunkSize = uint32le(chunkHeader, 4);

                long chunkStart = raf.getFilePointer();

                if (chunkSize < 0L
                        || chunkStart + chunkSize > raf.length()) {
                    throw new IOException("Invalid WAV chunk");
                }

                if (chunkName.equals("fmt ")) {
                    if (chunkSize < 16L) {
                        throw new IOException("Invalid WAV format chunk");
                    }

                    audioFormat = readUnsignedShortLE(raf);
                    channels = readUnsignedShortLE(raf);
                    sampleRate = readIntLE(raf);

                    raf.skipBytes(6);

                    bitsPerSample = readUnsignedShortLE(raf);

                } else if (chunkName.equals("data")) {
                    dataOffset = chunkStart;
                    dataSize = chunkSize;
                }

                raf.seek(
                        chunkStart + chunkSize + (chunkSize & 1L)
                );

                if (dataOffset >= 0L && channels > 0) {
                    break;
                }
            }

            if (audioFormat != 1) {
                throw new IOException("Only PCM WAV is supported");
            }

            if (bitsPerSample != 16) {
                throw new IOException("Only 16-bit WAV is supported");
            }

            if (channels != 1 && channels != 2) {
                throw new IOException("Only mono/stereo WAV is supported");
            }

            if (sampleRate <= 0 || dataOffset < 0L || dataSize < 0L) {
                throw new IOException("WAV audio data not found");
            }

            raf.seek(dataOffset);

            InputStream input = new LimitedFileInputStream(
                    raf,
                    dataSize
            );

            long duration =
                    dataSize * 1000L
                            / ((long) sampleRate * channels * 2L);

            return new DecodedPcmStream(
                    input,
                    sampleRate,
                    channels,
                    dataSize,
                    duration
            );

        } catch (Exception e) {
            try {
                raf.close();
            } catch (IOException ignored) {
            }

            if (e instanceof IOException ioException) {
                throw ioException;
            }

            throw new IOException("WAV decoding failed", e);
        }
    }

    private DecodedPcmStream decodeMp3WithJLayer(
            Path file
    ) throws IOException {

        JLayerPcmInputStream input =
                new JLayerPcmInputStream(file);

        int sampleRate = input.getSampleRate();
        int channels = input.getChannels();

        long fileSize = Files.size(file);

        // Approximate duration for a 128 kbps MP3.
        long durationMs = Math.max(1L, fileSize / 16L);

        long totalPcmBytes =
                durationMs * sampleRate * channels * 2L / 1000L;

        return new DecodedPcmStream(
                input,
                sampleRate,
                channels,
                totalPcmBytes,
                durationMs
        );
    }

    private static void skipFully(
            InputStream input,
            long bytes
    ) throws IOException {

        long remaining = Math.max(0L, bytes);

        while (remaining > 0L) {
            long skipped = input.skip(remaining);

            if (skipped <= 0L) {
                if (input.read() == -1) {
                    break;
                }
                skipped = 1L;
            }

            remaining -= skipped;
        }
    }

    private static String ascii(
            byte[] data,
            int offset,
            int length
    ) {
        return new String(
                data,
                offset,
                length,
                java.nio.charset.StandardCharsets.US_ASCII
        );
    }

    private static long uint32le(
            byte[] data,
            int offset
    ) {
        return (data[offset] & 0xFFL)
                | ((data[offset + 1] & 0xFFL) << 8)
                | ((data[offset + 2] & 0xFFL) << 16)
                | ((data[offset + 3] & 0xFFL) << 24);
    }

    private static int readUnsignedShortLE(
            RandomAccessFile raf
    ) throws IOException {
        int a = raf.read();
        int b = raf.read();

        if (a < 0 || b < 0) {
            throw new IOException("Unexpected end of WAV file");
        }

        return a | (b << 8);
    }

    private static int readIntLE(
            RandomAccessFile raf
    ) throws IOException {
        return (int) readUnsignedIntLE(raf);
    }

    private static long readUnsignedIntLE(
            RandomAccessFile raf
    ) throws IOException {
        long a = raf.read();
        long b = raf.read();
        long c = raf.read();
        long d = raf.read();

        if (a < 0 || b < 0 || c < 0 || d < 0) {
            throw new IOException("Unexpected end of WAV file");
        }

        return a | (b << 8) | (c << 16) | (d << 24);
    }

    private static float clamp01(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }

    private void stopPlaybackInternal() {
        playbackGeneration.incrementAndGet();

        playing.set(false);
        paused.set(false);

        Thread worker = streamingThread;
        streamingThread = null;

        if (worker != null) {
            worker.interrupt();
        }

        AndroidAudioSink sink = activeSink;
        activeSink = null;

        if (sink != null) {
            sink.release();
        }

        seekTargetMs.set(-1L);
        positionMs.set(0L);
    }

    public void shutdown() {
        stopPlaybackInternal();
        config.save();
        controlExecutor.shutdownNow();
    }

    private static final class DecodedPcmStream
            implements Closeable {

        private final InputStream stream;
        private final int sampleRate;
        private final int channels;
        private final long totalPcmBytes;
        private final long durationMs;

        private DecodedPcmStream(
                InputStream stream,
                int sampleRate,
                int channels,
                long totalPcmBytes,
                long durationMs
        ) {
            this.stream = stream;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.totalPcmBytes = totalPcmBytes;
            this.durationMs = durationMs;
        }

        public InputStream stream() {
            return stream;
        }

        public int sampleRate() {
            return sampleRate;
        }

        public int channels() {
            return channels;
        }

        public long totalPcmBytes() {
            return totalPcmBytes;
        }

        public long durationMs() {
            return durationMs;
        }

        @Override
        public void close() throws IOException {
            stream.close();
        }
    }

    private static final class LimitedFileInputStream
            extends InputStream {

        private final RandomAccessFile file;
        private long remaining;

        private LimitedFileInputStream(
                RandomAccessFile file,
                long length
        ) {
            this.file = file;
            this.remaining = length;
        }

        @Override
        public int read() throws IOException {
            if (remaining <= 0L) {
                return -1;
            }

            int value = file.read();

            if (value >= 0) {
                remaining--;
            }

            return value;
        }

        @Override
        public int read(
                byte[] buffer,
                int offset,
                int length
        ) throws IOException {

            if (remaining <= 0L) {
                return -1;
            }

            int requested = (int) Math.min(
                    length,
                    remaining
            );

            int count = file.read(
                    buffer,
                    offset,
                    requested
            );

            if (count > 0) {
                remaining -= count;
            }

            return count;
        }

        @Override
        public long skip(long amount) throws IOException {
            long skipped = Math.min(
                    Math.max(0L, amount),
                    remaining
            );

            file.seek(file.getFilePointer() + skipped);
            remaining -= skipped;

            return skipped;
        }

        @Override
        public void close() throws IOException {
            file.close();
        }
    }

    private static final class JLayerPcmInputStream
            extends InputStream {

        private final Bitstream bitstream;
        private final Decoder decoder;

        private byte[] frameBytes = new byte[0];
        private int framePosition;

        private int sampleRate;
        private int channels;

        private boolean finished;
        private boolean closed;

        private JLayerPcmInputStream(
                Path file
        ) throws IOException {

            bitstream = new Bitstream(
                    new java.io.BufferedInputStream(
                            Files.newInputStream(file)
                    )
            );

            decoder = new Decoder();

            try {
                if (!loadNextFrame()) {
                    throw new IOException("MP3 contains no audio frames");
                }
            } catch (Exception e) {
                try {
                    bitstream.close();
                } catch (Exception ignored) {
                }

                if (e instanceof IOException ioException) {
                    throw ioException;
                }

                throw new IOException("MP3 decoding failed", e);
            }
        }

        public int getSampleRate() {
            return sampleRate;
        }

        public int getChannels() {
            return channels;
        }

        private boolean loadNextFrame() throws IOException {
            if (finished || closed) {
                return false;
            }

            try {
                Header header = bitstream.readFrame();

                if (header == null) {
                    finished = true;
                    return false;
                }

                SampleBuffer samples;

                try {
                    samples = (SampleBuffer)
                            decoder.decodeFrame(header, bitstream);
                } finally {
                    bitstream.closeFrame();
                }

                short[] pcm = samples.getBuffer();
                int sampleCount = samples.getBufferLength();

                if (sampleRate == 0) {
                    sampleRate = samples.getSampleFrequency();
                    channels = samples.getChannelCount();

                    if (sampleRate <= 0
                            || (channels != 1 && channels != 2)) {
                        throw new IOException(
                                "Unsupported MP3 audio format"
                        );
                    }
                }

                frameBytes = new byte[sampleCount * 2];

                for (int i = 0; i < sampleCount; i++) {
                    short sample = pcm[i];

                    frameBytes[i * 2] =
                            (byte) (sample & 0xFF);

                    frameBytes[i * 2 + 1] =
                            (byte) ((sample >> 8) & 0xFF);
                }

                framePosition = 0;
                return true;

            } catch (Exception e) {
                finished = true;

                if (e instanceof IOException ioException) {
                    throw ioException;
                }

                throw new IOException(
                        "MP3 frame decoding failed",
                        e
                );
            }
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];

            int count = read(one, 0, 1);

            return count == -1 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(
                byte[] buffer,
                int offset,
                int length
        ) throws IOException {

            if (closed) {
                throw new IOException("Stream is closed");
            }

            if (length == 0) {
                return 0;
            }

            int copied = 0;

            while (copied < length) {
                if (framePosition >= frameBytes.length) {
                    if (!loadNextFrame()) {
                        break;
                    }
                }

                int available =
                        frameBytes.length - framePosition;

                int amount = Math.min(
                        available,
                        length - copied
                );

                System.arraycopy(
                        frameBytes,
                        framePosition,
                        buffer,
                        offset + copied,
                        amount
                );

                framePosition += amount;
                copied += amount;
            }

            return copied == 0 ? -1 : copied;
        }

        @Override
        public void close() throws IOException {
            if (closed) {
                return;
            }

            closed = true;

            try {
                bitstream.close();
            } catch (Exception e) {
                throw new IOException(
                        "Failed to close MP3 decoder",
                        e
                );
            }
        }
    }

    private static final class AndroidAudioSink {

        private static final int STREAM_MUSIC = 3;
        private static final int MODE_STREAM = 1;
        private static final int STATE_INITIALIZED = 1;

        private final Object audioTrack;

        private final Method playMethod;
        private final Method pauseMethod;
        private final Method flushMethod;
        private final Method releaseMethod;
        private final Method writeMethod;
        private final Method volumeMethod;
        private final Method stereoVolumeMethod;

        private final AtomicBoolean released =
                new AtomicBoolean(false);

        private AndroidAudioSink(
                int sampleRate,
                int channels,
                float volume
        ) throws Exception {

            Class<?> audioTrackClass =
                    Class.forName("android.media.AudioTrack");

            Class<?> audioFormatClass =
                    Class.forName("android.media.AudioFormat");

            int encoding = audioFormatClass
                    .getField("ENCODING_PCM_16BIT")
                    .getInt(null);

            int channelConfig = audioFormatClass
                    .getField(
                            channels == 1
                                    ? "CHANNEL_OUT_MONO"
                                    : "CHANNEL_OUT_STEREO"
                    )
                    .getInt(null);

            Method minBufferMethod =
                    audioTrackClass.getMethod(
                            "getMinBufferSize",
                            int.class,
                            int.class,
                            int.class
                    );

            int minBuffer = (int) minBufferMethod.invoke(
                    null,
                    sampleRate,
                    channelConfig,
                    encoding
            );

            if (minBuffer <= 0) {
                throw new IOException(
                        "Android AudioTrack buffer unavailable: "
                                + minBuffer
                );
            }

            Constructor<?> constructor =
                    audioTrackClass.getConstructor(
                            int.class,
                            int.class,
                            int.class,
                            int.class,
                            int.class,
                            int.class
                    );

            audioTrack = constructor.newInstance(
                    STREAM_MUSIC,
                    sampleRate,
                    channelConfig,
                    encoding,
                    Math.max(minBuffer * 2, 8192),
                    MODE_STREAM
            );

            int state = (int) audioTrackClass
                    .getMethod("getState")
                    .invoke(audioTrack);

            if (state != STATE_INITIALIZED) {
                audioTrackClass
                        .getMethod("release")
                        .invoke(audioTrack);

                throw new IOException(
                        "Android AudioTrack initialization failed"
                );
            }

            playMethod = audioTrackClass.getMethod("play");
            pauseMethod = audioTrackClass.getMethod("pause");
            flushMethod = audioTrackClass.getMethod("flush");
            releaseMethod = audioTrackClass.getMethod("release");

            writeMethod = audioTrackClass.getMethod(
                    "write",
                    byte[].class,
                    int.class,
                    int.class
            );

            Method setVolume = null;
            Method setStereoVolume = null;

            try {
                setVolume = audioTrackClass.getMethod(
                        "setVolume",
                        float.class
                );
            } catch (NoSuchMethodException ignored) {
                try {
                    setStereoVolume = audioTrackClass.getMethod(
                            "setStereoVolume",
                            float.class,
                            float.class
                    );
                } catch (NoSuchMethodException ignoredAgain) {
                }
            }

            volumeMethod = setVolume;
            stereoVolumeMethod = setStereoVolume;

            setVolume(volume);
        }

        public void play() {
            invoke(playMethod);
        }

        public void pause() {
            invoke(pauseMethod);
        }

        public void flush() {
            invoke(flushMethod);
        }

        public void setVolume(float volume) {
            float value = clamp01(volume);

            try {
                if (volumeMethod != null) {
                    volumeMethod.invoke(audioTrack, value);
                } else if (stereoVolumeMethod != null) {
                    stereoVolumeMethod.invoke(
                            audioTrack,
                            value,
                            value
                    );
                }
            } catch (Exception e) {
                LOGGER.warn(
                        "Could not change Android audio volume: {}",
                        e.getMessage()
                );
            }
        }

        public void write(
                byte[] data,
                int length
        ) throws Exception {

            int offset = 0;

            while (offset < length && !released.get()) {
                int written = (int) writeMethod.invoke(
                        audioTrack,
                        data,
                        offset,
                        length - offset
                );

                if (written < 0) {
                    throw new IOException(
                            "AudioTrack write failed: " + written
                    );
                }

                if (written == 0) {
                    Thread.sleep(5L);
                    continue;
                }

                offset += written;
            }
        }

        private void invoke(Method method) {
            if (released.get()) {
                return;
            }

            try {
                method.invoke(audioTrack);
            } catch (Exception e) {
                LOGGER.warn(
                        "AudioTrack operation failed: {}",
                        e.getMessage()
                );
            }
        }

        public void release() {
            if (!released.compareAndSet(false, true)) {
                return;
            }

            try {
                releaseMethod.invoke(audioTrack);
            } catch (Exception e) {
                LOGGER.warn(
                        "AudioTrack release failed: {}",
                        e.getMessage()
                );
            }
        }
    }
}

