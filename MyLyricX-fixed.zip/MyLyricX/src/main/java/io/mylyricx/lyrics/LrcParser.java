package io.mylyricx.lyrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LrcParser {
    private static final Logger LOGGER = LoggerFactory.getLogger("MyLyricX");
    private static final Pattern TIMESTAMP_PATTERN = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");
    private static final Pattern OFFSET_PATTERN = Pattern.compile("^\\[offset:([+-]?\\d+)\\]$", Pattern.CASE_INSENSITIVE);

    private LrcParser() {
    }

    public static List<LyricLine> parseFile(Path lrcPath) {
        if (lrcPath == null || !Files.isRegularFile(lrcPath)) {
            return List.of();
        }
        List<LyricLine> rawLines = new ArrayList<>();
        long offsetMs = 0L;

        try (BufferedReader reader = Files.newBufferedReader(lrcPath, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) {
                    continue;
                }
                if (trimmed.startsWith("\uFEFF")) {
                    trimmed = trimmed.substring(1).trim();
                }
                Matcher offsetMatcher = OFFSET_PATTERN.matcher(trimmed);
                if (offsetMatcher.matches()) {
                    try {
                        offsetMs = Long.parseLong(offsetMatcher.group(1));
                    } catch (NumberFormatException ignored) {
                    }
                    continue;
                }
                parseLine(trimmed, rawLines);
            }
        } catch (IOException e) {
            LOGGER.warn("Could not read LRC file {}: {}", lrcPath.getFileName(), e.getMessage());
            return List.of();
        }

        if (rawLines.isEmpty()) {
            return List.of();
        }

        List<LyricLine> adjusted = new ArrayList<>(rawLines.size());
        for (LyricLine item : rawLines) {
            long ts = Math.max(0L, item.timestampMs() - offsetMs);
            adjusted.add(new LyricLine(ts, item.text()));
        }
        Collections.sort(adjusted);
        return java.util.Collections.unmodifiableList(adjusted);

    static void parseLine(String rawLine, List<LyricLine> out) {
        Matcher matcher = TIMESTAMP_PATTERN.matcher(rawLine);
        List<Long> timestamps = new ArrayList<>();
        int lastMatchEnd = 0;

        while (matcher.find()) {
            long minutes = Long.parseLong(matcher.group(1));
            long seconds = Long.parseLong(matcher.group(2));
            String frac = matcher.group(3);
            long millis = 0L;
            if (frac != null) {
                if (frac.length() == 1) {
                    millis = Long.parseLong(frac) * 100L;
                } else if (frac.length() == 2) {
                    millis = Long.parseLong(frac) * 10L;
                } else {
                    millis = Long.parseLong(frac.substring(0, 3));
                }
            }
            long totalMs = (minutes * 60_000L) + (seconds * 1_000L) + millis;
            timestamps.add(totalMs);
            lastMatchEnd = matcher.end();
        }

        if (timestamps.isEmpty()) {
            return;
        }

        String lyricText = rawLine.substring(lastMatchEnd).trim();
        for (long ts : timestamps) {
            out.add(new LyricLine(ts, lyricText));
        }
    }

    public static int findActiveLineIndex(List<LyricLine> lyrics, long positionMs) {
        if (lyrics == null || lyrics.isEmpty()) {
            return -1;
        }
        int low = 0;
        int high = lyrics.size() - 1;
        int best = -1;

        while (low <= high) {
            int mid = (low + high) >>> 1;
            long ts = lyrics.get(mid).timestampMs();
            if (ts <= positionMs) {
                best = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return best;
    }
}
